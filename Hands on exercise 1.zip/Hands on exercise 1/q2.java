/*Exercise 2: E-commerce Platform Search Function
Scenario: 
You are working on the search functionality of an e-commerce platform. The search needs to be optimized for fast performance.
Steps:
1.	Understand Asymptotic Notation:
o	Explain Big O notation and how it helps in analyzing algorithms.
o	Describe the best, average, and worst-case scenarios for search operations.
2.	Setup:
o	Create a class Product with attributes for searching, such as productId, productName, and category.
3.	Implementation:
o	Implement linear search and binary search algorithms.
o	Store products in an array for linear search and a sorted array for binary search.
4.	Analysis:
o	Compare the time complexity of linear and binary search algorithms.
o	Discuss which algorithm is more suitable for your platform and why.*/

/*Big O Notation:
Big O notation is a mathematical notation used to describe the upper bound of an algorithm's running time. It characterizes functions according to their growth rates:
how the running time of an algorithm increases as the size of the input increases.
1.Big O notation helps understand how an algorithm's performance changes with varying input sizes, ensuring it scales efficiently.
2.It allows comparison of different algorithms based on their time and space complexities, regardless of hardware or software environment.
Bottleneck Identification: It helps in identifying performance bottlenecks in algorithms, enabling targeted optimization.
Best, Average, and Worst-Case Scenarios
Best Case: The scenario where the algorithm performs the minimum number of operations. For search operations, this typically occurs when the target element is at the first position.
Average Case: The expected scenario, averaging the operations over all possible inputs. This gives a more realistic performance expectation in practical use.
Worst Case: The scenario where the algorithm performs the maximum number of operations. For search operations, this usually occurs when the target element is at the last position or not present at all. */

public class Product {
    private String productId;
    private String productName;
    private String category;

    public Product(String productId, String productName, String category) {
        this.productId = productId;
        this.productName = productName;
        this.category = category;
    }

    // Getters
    public String getProductId() { return productId; }
    public String getProductName() { return productName; }
    public String getCategory() { return category; }

    @Override
    public String toString() {
        return "Product{" +
                "productId='" + productId + '\'' +
                ", productName='" + productName + '\'' +
                ", category='" + category + '\'' +
                '}';
    }
}
public class Product {
    private String productId;
    private String productName;
    private String category;

    public Product(String productId, String productName, String category) {
        this.productId = productId;
        this.productName = productName;
        this.category = category;
    }

    // Getters
    public String getProductId() { return productId; }
    public String getProductName() { return productName; }
    public String getCategory() { return category; }

    @Override
    public String toString() {
        return "Product{" +
                "productId='" + productId + '\'' +
                ", productName='" + productName + '\'' +
                ", category='" + category + '\'' +
                '}';
    }
}
public class LinearSearch {
    public Product linearSearch(Product[] products, String targetProductName) {
        for (Product product : products) {
            if (product.getProductName().equalsIgnoreCase(targetProductName)) {
                return product;
            }
        }
        return null; // Product not found
    }
}
import java.util.Arrays;
import java.util.Comparator;

public class BinarySearch {
    public Product binarySearch(Product[] products, String targetProductName) {
        Arrays.sort(products, Comparator.comparing(Product::getProductName));
        int left = 0;
        int right = products.length - 1;
        while (left <= right) {
            int mid = left + (right - left) / 2;
            int comparison = products[mid].getProductName().compareToIgnoreCase(targetProductName);
            if (comparison == 0) {
                return products[mid];
            } else if (comparison < 0) {
                left = mid + 1;
            } else {
                right = mid - 1;
            }
        }
        return null; // Product not found
    }
}
public class EcommercePlatform {
    public static void main(String[] args) {
        Product[] products = {
            new Product("101", "Laptop", "Electronics"),
            new Product("102", "Smartphone", "Electronics"),
            new Product("103", "Tablet", "Electronics"),
            new Product("104", "Headphones", "Accessories"),
            new Product("105", "Charger", "Accessories")
        };

        LinearSearch linearSearch = new LinearSearch();
        BinarySearch binarySearch = new BinarySearch();

        String targetProductName = "Tablet";

        Product resultLinear = linearSearch.linearSearch(products, targetProductName);
        System.out.println("Linear Search Result: " + (resultLinear != null ? resultLinear : "Product not found"));

        Product resultBinary = binarySearch.binarySearch(products, targetProductName);
        System.out.println("Binary Search Result: " + (resultBinary != null ? resultBinary : "Product not found"));
    }
}
/*4. Analysis
Time Complexity
Linear Search:
Best Case: O(1) - The target product is the first element.
Average Case: O(n) - The target product is somewhere in the middle.
Worst Case: O(n) - The target product is the last element or not present at all.
Binary Search:
Best Case: O(1) - The target product is the middle element.
Average Case: O(log n) - The target product requires a logarithmic number of comparisons.
Worst Case: O(log n) - The target product is at the end of the search range.
Suitability for the Platform
Linear Search:

Simple and does not require sorted data.
Suitable for small datasets due to its O(n) complexity.
Not efficient for large datasets.
Binary Search:

Requires the data to be sorted.
More efficient for large datasets due to its O(log n) complexity.
Ideal for large e-commerce platforms where the dataset is substantial. */