/*Exercise 1: Inventory Management System
Scenario: 
You are developing an inventory management system for a warehouse. Efficient data storage and retrieval are crucial.
Steps:
1.	Understand the Problem:
o	Explain why data structures and algorithms are essential in handling large inventories.
o	Discuss the types of data structures suitable for this problem.
2.	Setup:
o	Create a new project for the inventory management system.
3.	Implementation:
o	Define a class Product with attributes like productId, productName, quantity, and price.
o	Choose an appropriate data structure to store the products (e.g., ArrayList, HashMap).
o	Implement methods to add, update, and delete products from the inventory.
4.	Analysis:
o	Analyze the time complexity of each operation (add, update, delete) in your chosen data structure.
o	Discuss how you can optimize these operations.
 */

/* 1.a. Data structure and algorithm is essential for handling large inventories as it has the need to constantly update , delete and 
 store new datas . DSA helps in quick storage , retrieve and update the data .As the number of products in the inventory grows, the
   system must handle increased data without significant performance degradation. Proper data structures ensure that the system remains
   scalable, handling large volumes of data efficiently.It also helps in faster execution of operations.
  
 * 1.b. Types of Data Structures Suitable for Inventory Management are :
ArrayList: Elements are stored and accessed sequentially but can be slow for insertions and deletions in the middle.
HashMap: Provides average O(1) time complexity for insertions, deletions.Suitable for storing key-value pairs, where the product ID can be the key.
LinkedList: Efficient for insertions and deletions but slow for access as it requires traversing from the head node.
Binary Search Tree (BST): Allows for efficient searching, insertion, and deletion with average O(log n) time complexity but can degrade to O(n) if not balanced.
AVL Tree/Red-Black Tree: Balanced BSTs that ensure O(log n) time complexity for all operations.
 */

import java.util.HashMap;

public class Product{
    private String ProductId;
    private String ProductName;
    private int quality;
    private int Price;

    public Product(String ProductId , String ProductName , int quality, int Price ){
        this.ProductId = ProductId;
        this.ProductName = ProductName;
        this.quality = quality;
        this.Price = Price;
    }
    public String getProductId() { return productId; }
    public void setProductId(String productId) { this.productId = productId; }

    public String getProductName() { return productName; }
    public void setProductName(String productName) { this.productName = productName; }

    public int getQuantity() { return quantity; }
    public void setQuantity(int quantity) { this.quantity = quantity; }

    public double getPrice() { return price; }
    public void setPrice(double price) { this.price = price; }

    public String toString() {
        return "Product{" +
                "productId='" + productId + '\'' +
                ", productName='" + productName + '\'' +
                ", quantity=" + quantity +
                ", price=" + price +
                '}';
    }
}

public class Inventory {
    private HashMap<String, Product> inventory;

    public Inventory() {
        inventory = new HashMap<>();
    }

    // Method to add a product
    public void addProduct(Product product) {
        if (inventory.containsKey(product.getProductId())) {
            System.out.println("Product ID already exists. Use updateProduct to update the product.");
        } else {
            inventory.put(product.getProductId(), product);
            System.out.println("Product added: " + product);
        }
    }

    // Method to update a product
    public void updateProduct(String productId, Product updatedProduct) {
        if (inventory.containsKey(productId)) {
            inventory.put(productId, updatedProduct);
            System.out.println("Product updated: " + updatedProduct);
        } else {
            System.out.println("Product ID does not exist. Use addProduct to add the product.");
        }
    }

    // Method to delete a product
    public void deleteProduct(String productId) {
        if (inventory.containsKey(productId)) {
            Product removedProduct = inventory.remove(productId);
            System.out.println("Product removed: " + removedProduct);
        } else {
            System.out.println("Product ID does not exist.");
        }
    }

    // Method to get a product
    public Product getProduct(String productId) {
        return inventory.get(productId);
    }
}

public class InventoryManagementSystem {
    public static void main(String[] args) {
        Inventory inventory = new Inventory();

        Product p1 = new Product("101", "Laptop", 10, 999.99);
        Product p2 = new Product("102", "Smartphone", 20, 499.99);

        inventory.addProduct(p1);
        inventory.addProduct(p2);

        System.out.println("Product 101: " + inventory.getProduct("101"));
        System.out.println("Product 102: " + inventory.getProduct("102"));

        p1.setQuantity(15);
        inventory.updateProduct("101", p1);

        System.out.println("Updated Quantity of Product 101: " + inventory.getProduct("101").getQuantity());

        inventory.deleteProduct("102");
        System.out.println("Product 102 exists: " + (inventory.getProduct("102") != null));
    }
}
/*4. Analysis
Time Complexity
Add Product:
average time complexity is O(1).
Update Product:
average time complexity is O(1).
Delete Product:
average time complexity is O(1).
Get Product:
average time complexity is O(1).
Optimization
To optimize these operations:

Load Factor Management: Monitor and manage the load factor of the HashMap to ensure it remains efficient.
Data Validation: Implement validation checks before adding or updating products to prevent errors.
Concurrency Handling: If the system needs to handle concurrent access, use ConcurrentHashMap instead of HashMap for thread-safe operations.
Indexing: If additional queries are needed (e.g., search by product name), consider additional data structures or indexing methods. */
